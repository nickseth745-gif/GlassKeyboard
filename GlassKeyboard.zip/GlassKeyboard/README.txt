GLASS KEYBOARD - Android 14 keyboard (Kotlin)

BUILD
1. Install Android Studio (free): https://developer.android.com/studio
2. File > Open > choose this GlassKeyboard folder. Let Gradle sync finish.
3. Plug in your phone (Settings > About phone > tap Build number 7 times,
   then Settings > System > Developer options > turn on USB debugging).
4. Press the green Run button. The app installs on your phone.

   Or: Build > Build APK(s), copy app-debug.apk to your phone and open it.

TURN ON
1. Open the Glass Keyboard app.
2. Tap "1. Turn on Glass Keyboard" and switch it on.
3. Tap "2. Switch to Glass Keyboard" and pick it.
